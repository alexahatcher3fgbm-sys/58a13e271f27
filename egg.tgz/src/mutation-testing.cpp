// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("mutation testing\n", stdout);
  return lionss_run_workload("mutation-testing");
}
