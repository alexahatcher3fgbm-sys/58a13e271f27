// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("protocol fuzz"); }
int main(){
  announce();
  return lionss_run_workload("protocol-fuzz");
}
