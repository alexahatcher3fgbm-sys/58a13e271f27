// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("openbsd build"); }
int main(){
  announce();
  return lionss_run_workload("openbsd-build");
}
