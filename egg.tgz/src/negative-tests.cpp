// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("negative tests"); }
int main(){
  announce();
  return lionss_run_workload("negative-tests");
}
