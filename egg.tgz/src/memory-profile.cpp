// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("memory profile"); }
int main(){
  announce();
  return lionss_run_workload("memory-profile");
}
