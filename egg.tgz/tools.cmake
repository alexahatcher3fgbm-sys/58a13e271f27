# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(memory-sanitizer src/memory-sanitizer.cpp)
set_property(TARGET memory-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(memory-sanitizer lionss pthread)

add_executable(clang-16 src/clang-16.cpp)
set_property(TARGET clang-16 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-16 lionss pthread)

add_executable(contention-bench src/contention-bench.cpp)
set_property(TARGET contention-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(contention-bench lionss pthread)

add_executable(fuzz-corpus src/fuzz-corpus.cpp)
set_property(TARGET fuzz-corpus PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-corpus lionss pthread)

add_executable(package-rpm src/package-rpm.cpp)
set_property(TARGET package-rpm PROPERTY CXX_STANDARD 11)
target_link_libraries(package-rpm lionss pthread)

add_executable(memory-profile src/memory-profile.cpp)
set_property(TARGET memory-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(memory-profile lionss pthread)

add_executable(mutation-testing src/mutation-testing.cpp)
set_property(TARGET mutation-testing PROPERTY CXX_STANDARD 11)
target_link_libraries(mutation-testing lionss pthread)

add_executable(cross-toolchain src/cross-toolchain.cpp)
set_property(TARGET cross-toolchain PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-toolchain lionss pthread)

add_executable(quarantine-flaky src/quarantine-flaky.cpp)
set_property(TARGET quarantine-flaky PROPERTY CXX_STANDARD 11)
target_link_libraries(quarantine-flaky lionss pthread)

add_executable(mocked-tests src/mocked-tests.cpp)
set_property(TARGET mocked-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(mocked-tests lionss pthread)

add_executable(jumbo-build src/jumbo-build.cpp)
set_property(TARGET jumbo-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jumbo-build lionss pthread)

add_executable(protocol-fuzz src/protocol-fuzz.cpp)
set_property(TARGET protocol-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(protocol-fuzz lionss pthread)

add_executable(lto-build src/lto-build.cpp)
set_property(TARGET lto-build PROPERTY CXX_STANDARD 11)
target_link_libraries(lto-build lionss pthread)

add_executable(advisory-sync src/advisory-sync.cpp)
set_property(TARGET advisory-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(advisory-sync lionss pthread)

add_executable(spdx-sbom src/spdx-sbom.cpp)
set_property(TARGET spdx-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(spdx-sbom lionss pthread)

add_executable(sigstore-verify src/sigstore-verify.cpp)
set_property(TARGET sigstore-verify PROPERTY CXX_STANDARD 11)
target_link_libraries(sigstore-verify lionss pthread)

add_executable(sphinx-docs src/sphinx-docs.cpp)
set_property(TARGET sphinx-docs PROPERTY CXX_STANDARD 11)
target_link_libraries(sphinx-docs lionss pthread)

add_executable(openbsd-build src/openbsd-build.cpp)
set_property(TARGET openbsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(openbsd-build lionss pthread)

add_executable(conan-package src/conan-package.cpp)
set_property(TARGET conan-package PROPERTY CXX_STANDARD 11)
target_link_libraries(conan-package lionss pthread)

add_executable(clang-trunk src/clang-trunk.cpp)
set_property(TARGET clang-trunk PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-trunk lionss pthread)

add_executable(fuzz-minimize src/fuzz-minimize.cpp)
set_property(TARGET fuzz-minimize PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-minimize lionss pthread)

add_executable(ccache-stats src/ccache-stats.cpp)
set_property(TARGET ccache-stats PROPERTY CXX_STANDARD 11)
target_link_libraries(ccache-stats lionss pthread)

add_executable(syft-sbom src/syft-sbom.cpp)
set_property(TARGET syft-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(syft-sbom lionss pthread)

add_executable(broken-links src/broken-links.cpp)
set_property(TARGET broken-links PROPERTY CXX_STANDARD 11)
target_link_libraries(broken-links lionss pthread)

add_executable(debug-info-check src/debug-info-check.cpp)
set_property(TARGET debug-info-check PROPERTY CXX_STANDARD 11)
target_link_libraries(debug-info-check lionss pthread)

add_executable(icx-build src/icx-build.cpp)
set_property(TARGET icx-build PROPERTY CXX_STANDARD 11)
target_link_libraries(icx-build lionss pthread)

add_executable(negative-tests src/negative-tests.cpp)
set_property(TARGET negative-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(negative-tests lionss pthread)

add_executable(optional-features src/optional-features.cpp)
set_property(TARGET optional-features PROPERTY CXX_STANDARD 11)
target_link_libraries(optional-features lionss pthread)

add_executable(tvos-build src/tvos-build.cpp)
set_property(TARGET tvos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(tvos-build lionss pthread)

add_executable(acceptance-tests src/acceptance-tests.cpp)
set_property(TARGET acceptance-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(acceptance-tests lionss pthread)

